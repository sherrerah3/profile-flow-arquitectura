from .base import QuestionRepository
from questions.models import Question

class DjangoORMQuestionRepository(QuestionRepository):

    def create_question(self, text, options):
        return Question.objects.create(text=text, options=options)

    def list_questions(self):
        return list(Question.objects.values("id", "text", "options", "created_at"))