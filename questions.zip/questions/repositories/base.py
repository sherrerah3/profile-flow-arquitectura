from abc import ABC, abstractmethod
from typing import List, Dict

class QuestionRepository(ABC):

    @abstractmethod
    def create_question(self, text: str, options: List[str]):
        pass

    @abstractmethod
    def list_questions(self) -> List[Dict]:
        pass